Creat two browsers require('selenium-webdriver/chrome').Driver.createSession();
