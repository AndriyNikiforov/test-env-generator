from selenium.webdriver.chrome.options import Options

prefs = {
  "browser.enable_spellchecking": False,
  "browser.enable_autospellcorrect": False,
  "translate.enabled": False,
  "profile.managed_default_content_settings.images": 2,
  "profile.default_content_setting_values.notifications": 2,
  "profile.managed_default_content_settings.stylesheets": 2,
  "profile.managed_default_content_settings.cookies": 2,
  "profile.managed_default_content_settings.plugins": 2,
  "profile.managed_default_content_settings.popups": 2,
  "profile.managed_19default_content_settings.geolocation": 2,
  "profile.managed_default_content_settings.media_stream": 2,
}

options = Options()
options.add_argument("locationContextEnabled=false")
options.add_argument("webStorageEnabled=false")
options.add_argument("pageLoadStrategy=none")# self.options.add_argument("--headless")
options.add_argument("--use-double-buffering")
options.add_argument("--disable-in-process-stack-traces")
options.add_argument("--enable-power-overlay")
options.add_argument("--disable-renderer-backgrounding")
options.add_argument("--disable-multi-display-layout")
options.add_argument("--enable-quic")
options.add_argument("--no-default-browser-check")
options.add_argument("--no-first-run")
options.add_argument("--disable-direct-composition")
options.add_argument("--disable-partial-raster")
options.add_argument("--disable-gpu")
options.add_argument("--enable-tcp-fast-open")
options.add_argument("--disable-boot-animation")
options.add_argument("--disable-local-storage")
options.add_argument("--disable-infobars")
options.add_argument("--disable-display-color-calibration")
options.add_argument("--slow-connections-only")
options.add_argument("--wm-window-animations-disabled")
options.add_argument("--ignore-autocomplete-off-autofill")
options.add_argument("--ash-disable-smooth-screen-rotation")
options.add_argument("--extension-process")
options.add_argument("--aggressive")
options.add_argument("--aggressive-cache-discard")
options.add_argument("--disable-file-system")
options.add_argument("--eafe-url")
options.add_argument("--disable-contextual-search")
options.add_argument('--fast')
options.add_argument('--prerender')
options.add_argument('--no-sandbox')
options.add_argument('--enable-multiprocess')
options.add_argument('--disable-default-apps')
options.add_argument('--disable-remote-fonts')
options.add_argument('--disable-renderer-accessibility')
options.add_argument('--fast-start')
options.add_argument('--browser-test')
options.add_argument('--disable-cache')
options.add_argument('--disable-icon-ntp')
options.add_argument('--disk-cache-size=0')
options.add_argument('--disable-extensions')
options.add_argument('--disable-ntp-favicons')
options.add_argument('--disable-checker-imaging')
options.add_argument('--disable-application-cache')
options.add_argument('--ignore-certificate-errors')
options.add_argument('--disable-bundled-ppapi-flas')
options.add_argument('--disable-cached-picture-raster')
options.add_argument('--disable-rgba-4444-textures')
options.add_argument('--disable-search-geolocation-disclosure')
options.add_argument('--disabled-new-style-notification')
options.add_argument('--dom-automation')
options.add_argument('--eafe-path')
options.add_argument('--disable-gpu-watchdog')
options.add_argument('--disable-hang-monitor')
options.add_experimental_option('prefs', prefs)

