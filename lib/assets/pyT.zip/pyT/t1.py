"""
  Test module golang page.
"""

from lazy_import import lazy_module
lazy_module("selenium")
lazy_module("unittest")
lazy_module("selenium.webdriver.chrome.options")
lazy_module("config")

import unittest
from selenium import webdriver
from config import *

class TutTest(unittest.TestCase):
    """ Test methods """

    def setUp(self):
        """ Create chrome driver object and add config """

        self.driver = webdriver.Remote(
            command_executor="http://localhost:4444/wd/hub",
            desired_capabilities=options.to_capabilities()
        )

        self.driver.implicitly_wait(5)
        self.driver.set_window_size(800, 680)
        self.driver.get('https://www.ultimateqa.com/automation/')


    def test_run(self):
        """ Test actions """

    def tearDown(self):
        """ After test compleat actions """

        self.driver.quit()
        self.driver.stop_client()

if __name__ == '__main__':
    unittest.main()
