# Simple locus skeleton

Need to improve.