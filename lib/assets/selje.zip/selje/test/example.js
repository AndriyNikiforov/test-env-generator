require('cache-require-paths');

const { Options, Driver } = require('selenium-webdriver/chrome');
const { By, until } = require('selenium-webdriver');

const options = new Options().addArguments([
  '--headless',
  '--disable-infobars',
  '--enable-quic',
  '--disable-sync',
  '--disable-threaded-compositing',
  '--disable-zero-copy',
  '--disable-smooth-scrolling',
  '--no-first-run',
  '--disable-direct-composition',
  '--disable-partial-raster',
  '--disable-renderer-backgrounding',
  '--disable-component-extensions-with-background-pages',
  '--disable-background-timer-throttling',
  '--disable-gpu',
  '--enable-tcp-fast-open',
  '--disable-boot-animation',
  '--disable-local-storage',
  '--disable-infobars',
  '--disable-display-color-calibration',
  '--disable-distance-field-text',
  '--disable-accelerated-video-decode',
  '--slow-connections-only',
  '--hide-scrollbars',
  '--wm-window-animations-disabled',
  '--ignore-autocomplete-off-autofill',
  '--ash-disable-smooth-screen-rotation',
  '--extension-process',
  '--aggressive',
  '--aggressive-cache-discard',
  '--disable-file-system',
  '--eafe-url',
  '--disable-contextual-search',
  '--fast',
  '--prerender',
  '--no-sandbox',
  '--enable-multiprocess',
  '--disable-default-apps',
  '--disable-remote-fonts',
  '--disable-renderer-accessibility',
  '--fast-start',
  '--disable-gpu',
  '--browser-test',
  '--disable-cache',
  '--disable-icon-ntp',
  '--disk-cache-size=0',
  '--disable-extensions',
  '--disable-logging-redirect',
  '--disable-ntp-favicons',
  '--disable-checker-imaging',
  '--aggressive-cache-discard',
  '--disable-application-cache',
  '--ignore-certificate-errors',
  '--disable-bundled-ppapi-flas',
  '--disable-cached-picture-raster',
  '--disable-offline-load-stale-cache',
  '--dom-automation',
  '--eafe-path',
  '--disable-new-style-notification',
  '--use-double-buffering',
  '--disable-search-geolocation-disclosure',
  '--ignore-autocomplete-off-autofill',
  '--enable-power-overlay',
  '--zygote',
  '--disable-notifications'
]);

const chromeOne = Driver.createSession(options);

jest.setTimeout(900000);

describe('example', () => {
  it('test', async () => {
    await chromeOne.get('https://gowww.google.com')
      .then(async () => {
        // Something code
      })
      .catch(err => console.error(err));
  })
})
